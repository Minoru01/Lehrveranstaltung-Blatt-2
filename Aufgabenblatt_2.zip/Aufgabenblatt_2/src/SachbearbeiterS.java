import javax.swing.*;

/**
 * Created by robin on 11.11.2017.
 */
public class SachbearbeiterS{
    protected SachbearbeiterK sK = new SachbearbeiterK();
    protected JButton OKButton;
    protected JPanel stdScreen;
    protected JLabel fallLabel;
    protected JTextField benutzerFeld;
    protected JRadioButton sachbearbeiterRadioButton;
    protected JRadioButton administratorRadioButton;
    protected JTextField passwortFeld;
    protected JButton abbrechenButton;

    protected JPanel konfiguriereSachbearbeiterPanel(String ueberschrift, String defaultBenutzername, String defaultPasswort, boolean editierbar){
        fallLabel.setText(ueberschrift);
        benutzerFeld.setText(defaultBenutzername);
        passwortFeld.setText(defaultPasswort);
        sachbearbeiterRadioButton.setEnabled(editierbar);
        administratorRadioButton.setEnabled(editierbar);
        return stdScreen;
    }

    public JButton getOkButton(){
        return OKButton;
    }
    public JTextField getBenutzerFeld(){return benutzerFeld; }
}
