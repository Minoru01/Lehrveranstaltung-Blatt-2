import javax.swing.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

/**
 * Created by robin on 12.11.2017.
 */
public class SachbearbeiterEditierenAS extends SachbearbeiterS{
    protected final SachbearbeiterEditierenK seK = new SachbearbeiterEditierenK();
    protected JPanel editierenScreen;
    protected JPanel auswahlPanel;
    protected JPanel editierenPanel;
    private JLabel fallLabel2;

    public JComboBox getSachbarbeiterAuswahl() {
        return sachbarbeiterAuswahl;
    }

    protected final JComboBox sachbarbeiterAuswahl = fülleAuswahl();

    protected SachbearbeiterEditierenAS(){
        auswahlPanel.add(sachbarbeiterAuswahl);
        sachbarbeiterAuswahl.addItemListener(e -> {
            JComboBox jcb = (JComboBox) e.getSource();
            showSelectedItem(jcb);
        });
    }

    protected JPanel sachbarbeiterEditieren(boolean editierbar){
        editierenPanel.add(konfiguriereSachbearbeiterPanel("","","",editierbar));
        showSelectedItem(sachbarbeiterAuswahl);
        return editierenScreen;
    }

    protected JComboBox fülleAuswahl(){

        String[] alleNamen = seK.gibSachberarbeiterNamen();
        SachbearbeiterEditierenK.WrappedSachbarbeiter[] alleWrappedSachbarbeiter = new SachbearbeiterEditierenK.WrappedSachbarbeiter[alleNamen.length];
        int i = 0;
        String[] allWrappedNames= new String[alleNamen.length];
        for (String n : alleNamen){
            alleWrappedSachbarbeiter[i] = new SachbearbeiterEditierenK.WrappedSachbarbeiter(n);
            ++i;
        }

        return new JComboBox(alleWrappedSachbarbeiter);
    }

    protected void modifiziereSachbearbeiter(String alterName, String neuerName, String neueBerechtigung, String neuesPasswort) {
        seK.istLetzterAdmin(alterName, neueBerechtigung);
        seK.ändereSacharbeiter(alterName,neuerName,neueBerechtigung,neuesPasswort);
    }

    protected void showSelectedItem(JComboBox jcb){
        SachbearbeiterEditierenK.WrappedSachbarbeiter s = (SachbearbeiterEditierenK.WrappedSachbarbeiter) jcb.getSelectedItem();
        benutzerFeld.setText(seK.gibBenutzerName(s));
        passwortFeld.setText(seK.gibPasswort(s));
        if(seK.gibBerechtigung(s).equals("normal"))
            sachbearbeiterRadioButton.setSelected(true);
        else
            administratorRadioButton.setSelected(true);
    }
}
