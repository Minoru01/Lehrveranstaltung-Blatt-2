import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

/**
 * Created by robin on 11.11.2017.
 */
public class NormalAS {
    private static NormalAS actual;
    public JPanel normalInhalt;
    private NormalSachbearbeiterEditierenAAS nseASS = new NormalSachbearbeiterEditierenAAS();
    private JButton editierenButton;
    private JButton zurückButton;
    private JToolBar werkzeugLeiste;
    private JPanel normalOptionen;

    private final JMenuBar normalBar = createJMenuBar();
    private final JMenu normalSachbarbeiter = createJMenu("Sachbarbeiter");
    private final JMenu normalZurueck = createJMenu("Zurück");
    private final JMenuItem sachbearbeiterEditieren = createJMenuItem("Editieren");
    private final JMenuItem zurueckZurueck = createJMenuItem("Zurück");

    public NormalAS() {
        NormalAS.actual = this;

        editierenButton.addActionListener(e -> starteEditieren());

        sachbearbeiterEditieren.addActionListener(e -> starteEditieren());

        zurückButton.addActionListener(e -> startZurueck());

        zurueckZurueck.addActionListener(e -> startZurueck());
        sachbearbeiterEditieren.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
        zurueckZurueck.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
    }

    public static void normalSachbearbeiterEditierenAbschliessen(JPanel normalEditPanel) {
        actual.normalInhalt.remove(normalEditPanel);
        actual.enableComponents(true);
        actual.normalInhalt.validate();
        actual.normalInhalt.repaint();
    }

    private JMenuBar createJMenuBar() {
        JMenuBar retMenuBar = new JMenuBar();
        retMenuBar.setVisible(true);
        return retMenuBar;
    }

    private JMenu createJMenu(String text) {
        JMenu retMenu = new JMenu(text);
        retMenu.setVisible(true);
        return retMenu;
    }

    private JMenuItem createJMenuItem(String text) {
        return new JMenuItem(text);
    }

    private void initializeComponents() {
        normalSachbarbeiter.add(sachbearbeiterEditieren);
        normalZurueck.add(zurueckZurueck);
        normalBar.add(normalSachbarbeiter);
        normalBar.add(normalZurueck);
    }

    public void start(JFrame hs) {
        initializeComponents();
        hs.setJMenuBar(normalBar);
        hs.setContentPane(normalOptionen);
        refresh(hs);
    }

    private void refresh(JFrame hs) {
        hs.validate();
        hs.repaint();
    }

    private void enableComponents(boolean t) {
        this.normalSachbarbeiter.setEnabled(t);
        this.normalZurueck.setEnabled(t);
        this.editierenButton.setEnabled(t);
        this.zurückButton.setEnabled(t);
    }

    private void starteEditieren() {
        enableComponents(false);
        nseASS = new NormalSachbearbeiterEditierenAAS();
        normalInhalt.add(nseASS.normalSachbearbeiterEditieren());
        normalInhalt.validate();
        normalInhalt.repaint();
        LehrveranstaltungHS.setDefaultBtn(normalOptionen, nseASS.getOkButton());
        nseASS.getSachbarbeiterAuswahl().requestFocusInWindow();
    }

    private void startZurueck() {
        LehrveranstaltungHS.logout();
    }
}
