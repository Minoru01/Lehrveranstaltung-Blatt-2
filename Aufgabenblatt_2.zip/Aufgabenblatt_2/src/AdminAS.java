import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

/**
 * Created by robin on 13.11.2017.
 */
public class AdminAS {
    public static AdminAS actual;
    private AdminSachbearbeiterEditierenAAS aseAAS = new AdminSachbearbeiterEditierenAAS();
    private AdminSachbearbeiterErzeugenAAS asezAAS = new AdminSachbearbeiterErzeugenAAS();
    private AdminSachbearbeiterLöschenAAS aslAAS = new AdminSachbearbeiterLöschenAAS();

    private JPanel adminOptionen;
    private JToolBar werkzeugLeiste;
    private JPanel adminInhalt;
    private JButton editierenButton;
    private JButton erzeugenButton;
    private JButton löschenButton;
    private JButton zurückButton;

    private final JMenuBar adminBar = createJMenuBar();
    private final JMenu adminSachbarbeiter = createJMenu("Sachbarbeiter");
    private final JMenu adminZurueck = createJMenu("Zurück");
    private final JMenuItem sachbearbeiterErzeugen = createJMenuItem("Erzeugen");
    private final JMenuItem sachbearbeiterEditieren = createJMenuItem("Editieren");
    private final JMenuItem sachbearbeiterLöschen = createJMenuItem("Löschen");
    private final JMenuItem zurueckZurueck = createJMenuItem("Zurück");

    public AdminAS() {

        actual = this;

        erzeugenButton.addActionListener(e -> startErzeugen());

        sachbearbeiterErzeugen.addActionListener(e -> startErzeugen());

        editierenButton.addActionListener(e -> startEditieren());

        sachbearbeiterEditieren.addActionListener(e -> startEditieren());

        löschenButton.addActionListener(e -> startLöschen());

        sachbearbeiterLöschen.addActionListener(e -> startLöschen());

        zurückButton.addActionListener(e -> startZurueck());

        zurueckZurueck.addActionListener(e -> startZurueck());
        sachbearbeiterErzeugen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
        sachbearbeiterLöschen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
        sachbearbeiterEditieren.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
        zurueckZurueck.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, KeyEvent.ALT_DOWN_MASK + InputEvent.SHIFT_DOWN_MASK));
    }

    public static void adminSachbearbeiterEditierenAbschliessen(JPanel adminEditPanel) {
        actual.adminInhalt.remove(adminEditPanel);
        actual.enableComponents(true);
        actual.adminInhalt.validate();
        actual.adminInhalt.repaint();
    }

    public static void adminSachbearbeiterErzeugenAbschliessen(JPanel adminEditPanel) {
        actual.adminInhalt.remove(adminEditPanel);
        actual.enableComponents(true);
        actual.adminInhalt.validate();
        actual.adminInhalt.repaint();
    }

    public static void adminSachbearbeiterLöschenAbschliessen(JPanel adminEditPanel) {
        actual.adminInhalt.remove(adminEditPanel);
        actual.enableComponents(true);
        actual.adminInhalt.validate();
        actual.adminInhalt.repaint();
    }

    private void initializeComponents() {
        adminSachbarbeiter.add(sachbearbeiterErzeugen);
        adminSachbarbeiter.add(sachbearbeiterEditieren);
        adminSachbarbeiter.add(sachbearbeiterLöschen);
        adminZurueck.add(zurueckZurueck);
        adminBar.add(adminSachbarbeiter);
        adminBar.add(adminZurueck);
    }

    public void start(JFrame hs) {
        initializeComponents();
        hs.setJMenuBar(adminBar);
        hs.setContentPane(adminOptionen);
        hs.validate();
        hs.repaint();
    }

    private JMenuBar createJMenuBar() {
        JMenuBar retMenuBar = new JMenuBar();
        retMenuBar.setVisible(true);
        return retMenuBar;
    }

    private JMenu createJMenu(String text) {
        JMenu retMenu = new JMenu(text);
        retMenu.setVisible(true);
        return retMenu;
    }

    private JMenuItem createJMenuItem(String text) {
        return new JMenuItem(text);
    }

    private void startErzeugen() {
        enableComponents(false);
        asezAAS = new AdminSachbearbeiterErzeugenAAS();
        adminInhalt.add(asezAAS.adminSachbearbeiterErzeugen());
        adminInhalt.validate();
        adminInhalt.repaint();
        LehrveranstaltungHS.setDefaultBtn(adminOptionen, asezAAS.getOkButton());
        asezAAS.getBenutzerFeld().requestFocusInWindow();
    }

    private void startEditieren() {
        enableComponents(false);
        aseAAS = new AdminSachbearbeiterEditierenAAS();
        adminInhalt.add(aseAAS.adminSachbearbeiterEditieren());
        adminInhalt.validate();
        adminInhalt.repaint();
        LehrveranstaltungHS.setDefaultBtn(adminOptionen, aseAAS.getOkButton());
        aseAAS.getSachbarbeiterAuswahl().requestFocusInWindow();
    }

    private void startLöschen() {
        enableComponents(false);
        aslAAS = new AdminSachbearbeiterLöschenAAS();
        adminInhalt.add(aslAAS.adminSachbearbeiterLöschen());
        adminInhalt.validate();
        adminInhalt.repaint();
        LehrveranstaltungHS.setDefaultBtn(adminOptionen, aslAAS.getLöschenButton());
        aslAAS.getSachbearbeiterAuswahl().requestFocusInWindow();
    }

    private void startZurueck() {
        LehrveranstaltungHS.logout();
    }

    private void enableComponents(boolean t) {
        this.adminSachbarbeiter.setEnabled(t);
        this.adminZurueck.setEnabled(t);
        this.erzeugenButton.setEnabled(t);
        this.editierenButton.setEnabled(t);
        this.löschenButton.setEnabled(t);
        this.zurückButton.setEnabled(t);
    }
}
