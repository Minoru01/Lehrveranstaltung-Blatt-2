import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by robin on 13.11.2017.
 */
public class AdminSachbearbeiterEditierenAAS extends SachbearbeiterEditierenAS{
    //public AdminSachbearbeiterEditierenK nseK = new AdminSachbearbeiterEditierenK();

    public AdminSachbearbeiterEditierenAAS(){
        //LehrveranstaltungHS.setDefaultBtn(OKButton);
        OKButton.addActionListener(e -> {
            try {
                String an = seK.gibBenutzerName(sachbarbeiterAuswahl.getSelectedItem());
                String nn = benutzerFeld.getText();
                String np = passwortFeld.getText();
                String nb = "admin";
                if (sachbearbeiterRadioButton.isSelected())
                    nb = "normal";

                modifiziereSachbearbeiter(an,nn,nb,np);
                AdminAS.adminSachbearbeiterEditierenAbschliessen(sachbarbeiterEditieren(true));
            } catch (NullPointerException e1){
                JOptionPane.showMessageDialog(null,e1.getMessage(),"Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });

        abbrechenButton.addActionListener(e -> AdminAS.adminSachbearbeiterEditierenAbschliessen(sachbarbeiterEditieren(true)));
    }

    public JPanel adminSachbearbeiterEditieren() {
        return sachbarbeiterEditieren(true);
    }
}
