/**
 * Created by robin on 13.10.2017.
 */
public class SachbearbeiterK {

    public SachbearbeiterK() {}
}
