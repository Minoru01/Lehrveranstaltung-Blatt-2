import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Created by robin on 11.11.2017.
 */

public class LehrveranstaltungHS {
    public static LehrveranstaltungHS hs = new LehrveranstaltungHS();
    public static void setDefaultBtn(JPanel screen, JButton defaultButton){
       screen.getRootPane().setDefaultButton(defaultButton);
    }


    private LoginAS lAS;
    private final JFrame window;
    private final JMenuBar menuBar;
    private final JMenu loginMenu;
    private final JMenu beendenMenu;
    private final JMenuItem loginMenuItem;
    private final JMenuItem beendenMenuItem;

    private JPanel startFenster;
    private JToolBar werkzeugleiste;
    private JButton loginButton;
    private JButton beendenButton;
    private JPanel inhalt;

    public LehrveranstaltungHS() {
        window = createJFrame();
        menuBar = createJMenuBar();
        loginMenu = createJMenu("Login");
        beendenMenu = createJMenu("Beenden");
        loginMenuItem = createJMenuItem("Login");
        beendenMenuItem = createJMenuItem("Beenden");

        //window.addKeyListener(this);

        loginButton.addActionListener(e -> {login();});

        beendenButton.addActionListener(e -> System.exit(0));

        loginMenuItem.addActionListener(e -> {login();});

        beendenMenuItem.addActionListener(e -> System.exit(0));

        beendenMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B, KeyEvent.ALT_DOWN_MASK+ InputEvent.SHIFT_DOWN_MASK));
        loginMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, KeyEvent.ALT_DOWN_MASK+InputEvent.SHIFT_DOWN_MASK));


        initializeComponets();

        hs = this;
    }



    private JMenuBar createJMenuBar() {
        JMenuBar retMenuBar = new JMenuBar();
        retMenuBar.setVisible(true);
        return retMenuBar;
    }

    private JFrame createJFrame() {
        Dimension maxDim = Toolkit.getDefaultToolkit().getScreenSize();
        JFrame retFrame = new JFrame("Lehrveranstaltungsverwaltung");
        retFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        retFrame.setSize(maxDim);
        retFrame.setResizable(false);
        retFrame.setVisible(true);
        return retFrame;
    }

    private JMenu createJMenu(String text) {
        JMenu retMenu = new JMenu(text);
        retMenu.setVisible(true);
        //retMenu.setPreferredSize(new Dimension(50,20));
        return retMenu;
    }

    private JMenuItem createJMenuItem(String text) {
        return new JMenuItem(text);
    }
    
    private void initializeComponets(){
        this.window.setContentPane(this.startFenster);
        this.loginMenu.add(this.loginMenuItem);
        this.beendenMenu.add(this.beendenMenuItem);
        this.menuBar.add(this.loginMenu);
        this.menuBar.add(this.beendenMenu);
        this.window.setJMenuBar(this.menuBar);
        this.window.setVisible(true);
    }

    public static void main(String[] args) {
        new Sachbearbeiter("Robin","admin");
        new Sachbearbeiter("Luis","admin");
        new Sachbearbeiter("Lang","normal");
        new Sachbearbeiter("Jeff","normal");
        new Sachbearbeiter("Jess","normal");
        new Sachbearbeiter("Java_Gott","normal");

    }

    public static void loginBeenden(int akteur, JPanel loginPanel) {
        LehrveranstaltungHS.hs.inhalt.remove(loginPanel);
        LehrveranstaltungHS.hs.enableComponents(true);
        LehrveranstaltungHS.hs.refresh();
        if (akteur == 1){
            new NormalAS().start(LehrveranstaltungHS.hs.window);
        }
        else if(akteur == 2){
            new AdminAS().start(LehrveranstaltungHS.hs.window);
        }

    }

    public static void logout(){
        hs.initializeComponets();
    }

    public void refresh(){
        hs.window.validate();
        hs.window.repaint();
    }

    private void enableComponents(boolean t){
        hs.loginMenu.setEnabled(t);
        hs.loginButton.setEnabled(t);
        hs.beendenMenu.setEnabled(t);
        hs.beendenButton.setEnabled(t);
    }

    private void login(){
        enableComponents(false);
        lAS = new LoginAS();
        hs.inhalt.add(lAS.login());
        LehrveranstaltungHS.setDefaultBtn(startFenster, lAS.getOkButton());
        refresh();
        lAS.getBenutzerFeld().requestFocusInWindow();
    }
}
