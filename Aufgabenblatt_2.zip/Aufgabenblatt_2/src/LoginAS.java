import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by robin on 11.11.2017.
 */
public class LoginAS extends SachbearbeiterS {
    private final LoginK lK = new LoginK();
    private JPanel Login;

    public LoginAS() {
        Login.add(stdScreen);
        fallLabel.setText("Login:");

        OKButton.addActionListener(e -> {
            try {
                System.out.println("Starting ...");
                String berechtigung = "normal";
                int numBerechtigung = 1;
                if (administratorRadioButton.isSelected()) {
                    berechtigung = "admin";
                    numBerechtigung = 2;
                }
                String user = benutzerFeld.getText();
                String passwort = passwortFeld.getText();
                lK.loginSachbearbeiter(user, berechtigung, passwort);
                System.out.println("Success");
                LehrveranstaltungHS.loginBeenden(numBerechtigung,Login);
            } catch (NullPointerException e1) {
                JOptionPane.showMessageDialog(null,e1.getMessage(),"Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });

        abbrechenButton.addActionListener(e -> LehrveranstaltungHS.loginBeenden(0,Login));

    }

    public JPanel login() {
        Login.setVisible(true);
        benutzerFeld.requestFocusInWindow();
        return Login;
    }

}
