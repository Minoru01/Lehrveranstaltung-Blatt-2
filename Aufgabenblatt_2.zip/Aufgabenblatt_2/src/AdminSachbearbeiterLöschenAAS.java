import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

/**
 * Created by robin on 14.11.2017.
 */
public class AdminSachbearbeiterLöschenAAS {
    private final AdminSachbearbeiterLöschenK aslK = new AdminSachbearbeiterLöschenK();

    public JTextField getBenutzerFeld() {
        return benutzerFeld;
    }

    private JTextField benutzerFeld;
    private JTextField passwortFeld;
    private JRadioButton sachbearbeiterRadioButton;
    private JRadioButton administratorRadioButton;
    private JButton abbrechenButton;
    private JButton löschenButton;
    private JPanel löschenScreen;
    private JPanel auswahlScreen;

    public JComboBox getSachbearbeiterAuswahl() {
        return sachbearbeiterAuswahl;
    }

    private final JComboBox sachbearbeiterAuswahl = fülleAuswahl();

    public JButton getLöschenButton(){
        return löschenButton;
    }

    public AdminSachbearbeiterLöschenAAS() {
        //LehrveranstaltungHS.setDefaultBtn(löschenButton);
        auswahlScreen.add(sachbearbeiterAuswahl);
        showSelectedItem(sachbearbeiterAuswahl);
        auswahlScreen.validate();
        auswahlScreen.repaint();
        enableComponets();

        sachbearbeiterAuswahl.addItemListener(e -> {
            JComboBox jcb = (JComboBox) e.getSource();
            showSelectedItem(jcb);
        });

        abbrechenButton.addActionListener(e -> AdminAS.adminSachbearbeiterLöschenAbschliessen(löschenScreen));

        löschenButton.addActionListener(e -> {
            try {
                AdminSachbearbeiterLöschenK.WrappedSachbarbeiter s = (AdminSachbearbeiterLöschenK.WrappedSachbarbeiter) sachbearbeiterAuswahl.getSelectedItem();
                aslK.löscheSachbearbeiter(new AdminSachbearbeiterLöschenK().gibBenutzerName(s));
                AdminAS.adminSachbearbeiterLöschenAbschliessen(löschenScreen);
            } catch (NullPointerException e1) {
                JOptionPane.showMessageDialog(null, e1.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JComboBox fülleAuswahl() {
        String[] alleNamen = aslK.gibSachberarbeiterNamen();
        AdminSachbearbeiterLöschenK.WrappedSachbarbeiter[] alleWrappedSachbarbeiter = new AdminSachbearbeiterLöschenK.WrappedSachbarbeiter[alleNamen.length];
        int i = 0;
        for (String n : alleNamen) {
            System.out.println(n);
            alleWrappedSachbarbeiter[i] = new AdminSachbearbeiterLöschenK.WrappedSachbarbeiter(n);
            ++i;
        }

        return new JComboBox(alleWrappedSachbarbeiter);
    }

    public JPanel adminSachbearbeiterLöschen() {
        return löschenScreen;
    }

    private void enableComponets() {
        benutzerFeld.setEditable(false);
        passwortFeld.setEditable(false);
        sachbearbeiterRadioButton.setEnabled(false);
        administratorRadioButton.setEnabled(false);
    }

    private void showSelectedItem(JComboBox jcb){
        AdminSachbearbeiterLöschenK.WrappedSachbarbeiter s = (AdminSachbearbeiterLöschenK.WrappedSachbarbeiter) jcb.getSelectedItem();
        benutzerFeld.setText(aslK.gibBenutzerName(s));
        passwortFeld.setText(aslK.gibPasswort(s));
        if (aslK.gibBerechtigung(s).equals("normal"))
            sachbearbeiterRadioButton.setSelected(true);
        else
            administratorRadioButton.setSelected(true);
    }


}
