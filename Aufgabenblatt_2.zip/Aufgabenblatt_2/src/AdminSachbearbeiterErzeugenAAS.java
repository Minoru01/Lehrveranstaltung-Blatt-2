import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by robin on 13.11.2017.
 */
public class AdminSachbearbeiterErzeugenAAS extends SachbearbeiterS {
    public final AdminSachbearbeiterErzeugenK aseK = new AdminSachbearbeiterErzeugenK();

    public AdminSachbearbeiterErzeugenAAS() {
        //LehrveranstaltungHS.setDefaultBtn(OKButton);
        OKButton.addActionListener(e -> {
            try {
                String nn = benutzerFeld.getText();
                String np = passwortFeld.getText();
                String nb = "admin";
                if (sachbearbeiterRadioButton.isSelected())
                    nb = "normal";
                aseK.erzeugeSachbearbeiter(nn, nb, np);
                AdminAS.adminSachbearbeiterEditierenAbschliessen(adminSachbearbeiterErzeugen());
            } catch (NullPointerException e1){
                JOptionPane.showMessageDialog(null,e1.getMessage(),"Fehler", JOptionPane.ERROR_MESSAGE);
            }

        });

        abbrechenButton.addActionListener(e -> AdminAS.adminSachbearbeiterErzeugenAbschliessen(adminSachbearbeiterErzeugen()));
    }

    public JPanel adminSachbearbeiterErzeugen() {
        JPanel retPanel = konfiguriereSachbearbeiterPanel("Neuer Sachbearbeiter:", "", "", true);
        OKButton.setText("Erzeugen");
        return retPanel;
    }
}
