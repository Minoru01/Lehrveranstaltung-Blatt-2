/**
 * Created by robin on 14.10.2017.
 */
public class AdminSachbearbeiterErzeugenK {
    /*
     * erzeugt eine Instanz mit dem namen und gibt ihm die berechtigung normal
     */
    public void erzeugeSachbearbeiter(String name, String berechtigung, String passwort){
        new Sachbearbeiter(name, berechtigung , passwort);
        new Sachbearbeiter(Sachbearbeiter.gib(name));
    }
}
